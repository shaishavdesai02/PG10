package kekaTestCases;

import org.testng.annotations.Test;
import kekaResources.KekaBase;

public class TC_Dashboard extends KekaBase {

    @Test(priority = 2)
    public void verifyDashboardButtons() throws InterruptedException {
		log.info("Clicking all dashboard buttons");
		dash.clickAllDashboardButtons();
		Thread.sleep(1000);
    }
}
