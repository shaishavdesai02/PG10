package kekaPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Dashboard {

	WebDriver driver;

	public Dashboard(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "/html/body/div[2]/div/div[1]/div[1]/div/div/div[2]/div[1]/div[3]/div/button[1]")
	WebElement filterButton;

	@FindBy(xpath = "/html/body/div[2]/div/div[1]/div[1]/div/div/div[2]/div[1]/div[3]/div/button[2]")
	WebElement viewTxsButton;

	@FindBy(xpath = "/html/body/div[2]/div/div[1]/div[1]/div/div/div[2]/div[1]/div[3]/div/a[1]")
	WebElement velocityButton;

	//@FindBy(xpath = "//button[contains(text(),'Velocity With Pending')]")
	//WebElement velocityWithPendingButton;

	//@FindBy(xpath = "//button[contains(text(),'Reset')]")
	//WebElement resetButton;

	public void clickAllDashboardButtons() throws InterruptedException {
		filterButton.click();
		Thread.sleep(500);
		viewTxsButton.click();
		Thread.sleep(500);
		velocityButton.click();
		Thread.sleep(500);
		//velocityWithPendingButton.click();
		//Thread.sleep(500);
		//resetButton.click();
	}
}
